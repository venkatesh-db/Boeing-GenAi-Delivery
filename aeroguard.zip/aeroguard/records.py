"""Fleet, maintenance and AD compliance records (read by the MCP server on Day 5)."""
from __future__ import annotations

from functools import lru_cache

import pandas as pd

from aeroguard.config import DATA_DIR


@lru_cache
def fleet() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "fleet.csv")


@lru_cache
def logs() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "maintenance_logs.csv")


@lru_cache
def ad_compliance() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "ad_compliance.csv").fillna("")


def aircraft(tail_number: str) -> dict | None:
    rows = fleet()[fleet()["tail_number"] == tail_number]
    return rows.iloc[0].to_dict() if len(rows) else None


def maintenance_history(tail_number: str, ata_chapter: int | None = None, limit: int = 10) -> list[dict]:
    df = logs()[logs()["tail_number"] == tail_number]
    if ata_chapter is not None:
        df = df[df["ata_chapter"] == ata_chapter]
    cols = ["log_id", "date", "ata_chapter", "component", "description", "severity", "status"]
    return df.sort_values("date", ascending=False).head(limit)[cols].to_dict(orient="records")


def ad_status(tail_number: str) -> list[dict]:
    df = ad_compliance()[ad_compliance()["tail_number"] == tail_number]
    return df[["ad_number", "ata_chapter", "subject", "status", "complied_date"]].to_dict(orient="records")
