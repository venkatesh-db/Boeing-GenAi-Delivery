"""Day 4 — embeddings with a disk cache (Performance I: never pay twice for the same text)."""
from __future__ import annotations

import hashlib
import json
import threading

from langchain_core.embeddings import Embeddings

from aeroguard import llm
from aeroguard.config import STORAGE_DIR, get_settings

CACHE_FILE = STORAGE_DIR / "embedding_cache.json"
BATCH = 16


class CachedEmbeddings(Embeddings):
    def __init__(self, use_cache: bool = True):
        self.use_cache = use_cache
        self.model = get_settings().embed_model
        self._lock = threading.Lock()
        self._cache: dict[str, list[float]] = {}
        if use_cache and CACHE_FILE.exists():
            self._cache = json.loads(CACHE_FILE.read_text())
        self.hits = 0
        self.misses = 0

    def _key(self, text: str) -> str:
        return hashlib.sha256(f"{self.model}\n{text}".encode()).hexdigest()

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        keys = [self._key(t) for t in texts]
        missing = [i for i, k in enumerate(keys) if not (self.use_cache and k in self._cache)]
        self.hits += len(texts) - len(missing)
        self.misses += len(missing)
        new: dict[str, list[float]] = {}
        for start in range(0, len(missing), BATCH):
            batch = missing[start:start + BATCH]
            for i, vector in zip(batch, llm.embed([texts[i] for i in batch])):
                new[keys[i]] = vector
        with self._lock:
            self._cache.update(new)
            if self.use_cache and new:
                CACHE_FILE.parent.mkdir(exist_ok=True)
                CACHE_FILE.write_text(json.dumps(self._cache))
            return [self._cache.get(k) or new[k] for k in keys]

    def embed_query(self, text: str) -> list[float]:
        return self.embed_documents([text])[0]
