"""Day 4 — question answering with citations, a no-answer policy and guardrails.

The retrieval and generation steps run as a LangChain chain (see chain.py);
this module applies the policies around it.
"""
from __future__ import annotations

import re

from aeroguard import llm, safety, tracing
from aeroguard.rag import guardrails
from aeroguard.rag.chain import NOT_FOUND, build_rag_chain
from aeroguard.rag.store import KnowledgeBase, get_kb
from aeroguard.schemas import AskResponse, Citation

NO_ANSWER = ("I could not find this in the approved documents, so I won't guess. "
             "Check the AMM, the applicable ADs, or ask engineering.")


def answer(question: str, role: str = "technician", k: int = 4, kb: KnowledgeBase | None = None) -> AskResponse:
    question = guardrails.redact_pii(question)
    chain, retriever = build_rag_chain(kb or get_kb(), role=role, k=k)
    with tracing.span("rag.answer", role=role), llm.friendly_errors():
        result = chain.invoke(question)
    raw, warnings = result["answer"], result["warnings"]

    cited = set(re.findall(r"\[(S\d+)\]", raw))
    if not result["citations"] or NOT_FOUND in raw or not cited:
        return AskResponse(answer=NO_ANSWER, citations=[], answered=False, warnings=warnings,
                           retrieval_ms=retriever.last_ms)
    final = safety.enforce_advisory(question, guardrails.redact_pii(raw))
    return AskResponse(
        answer=final,
        citations=[Citation(**c) for c in result["citations"] if c["source_id"] in cited],
        answered=final != safety.REFUSAL,
        warnings=warnings,
        retrieval_ms=retriever.last_ms,
    )
