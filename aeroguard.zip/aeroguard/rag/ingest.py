"""Day 4 — load documents with metadata and split them into chunks (LangChain)."""
from __future__ import annotations

import re
from pathlib import Path

from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

ALLOWED_SUFFIXES = {".md", ".txt", ".pdf"}
_FRONT_MATTER = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def _split_front_matter(text: str) -> tuple[dict, str]:
    """Read the `key: value` header that each course document starts with."""
    match = _FRONT_MATTER.match(text)
    if not match:
        return {}, text
    meta = {}
    for line in match.group(1).splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip()
    return meta, text[match.end():]


def load_file(path: Path, default_access: str = "public") -> list[Document]:
    if path.suffix.lower() not in ALLOWED_SUFFIXES:
        raise ValueError(f"unsupported file type {path.suffix}; use {sorted(ALLOWED_SUFFIXES)}")
    if path.suffix.lower() == ".pdf":
        pages = PyPDFLoader(str(path)).load()
        meta, body = {}, "\n".join(p.page_content for p in pages)
    else:
        meta, body = _split_front_matter(TextLoader(str(path), encoding="utf-8").load()[0].page_content)
    metadata = {
        "doc_id": meta.get("doc_id", path.stem),
        "doc_type": meta.get("doc_type", "uploaded"),
        "aircraft_model": meta.get("aircraft_model", "ALL"),
        "ata_chapter": meta.get("ata_chapter", ""),
        "access": meta.get("access", default_access),
        "effective_date": meta.get("effective_date", ""),
        "source": path.name,
    }
    return [Document(page_content=body.strip(), metadata=metadata)]


def load_directory(folder: Path) -> list[Document]:
    docs: list[Document] = []
    for path in sorted(folder.iterdir()):
        if path.suffix.lower() in ALLOWED_SUFFIXES:
            docs.extend(load_file(path))
    return docs


def split(docs: list[Document], chunk_size: int = 700, chunk_overlap: int = 100) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=chunk_overlap, separators=["\n## ", "\n\n", "\n", ". ", " "]
    )
    chunks = splitter.split_documents(docs)
    for i, chunk in enumerate(chunks):
        title = chunk.metadata["doc_id"]
        # Prefix the document id so every chunk carries its own context for search
        chunk.page_content = f"[{title}] {chunk.page_content}"
        chunk.metadata["chunk_id"] = f"{chunk.metadata['source']}#{i}"
    return chunks
