"""Day 4 — hybrid retrieval: FAISS vectors + BM25 keywords, merged with reciprocal rank fusion."""
from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass
from functools import lru_cache

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from rank_bm25 import BM25Okapi

from aeroguard import tracing
from aeroguard.config import DOCS_DIR
from aeroguard.rag.embeddings import CachedEmbeddings
from aeroguard.rag.ingest import load_directory, split

ROLE_ACCESS = {"technician": {"public"}, "inspector": {"public", "restricted"}}
RRF_K = 60
# Identifiers such as "AD 2026-TR-0101" or "AMM 72-00-00" must match exactly, whatever the vectors say
_IDENTIFIER = re.compile(r"\b\d{4}-[a-z]{2}-\d{4}\b|\b\d{2}-\d{2}-\d{2}\b", re.IGNORECASE)


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)*", text.lower())


@dataclass(frozen=True)
class Hit:
    doc: Document
    score: float
    vector_rank: int | None
    keyword_rank: int | None


class KnowledgeBase:
    def __init__(self, chunks: list[Document], embeddings: CachedEmbeddings):
        self.embeddings = embeddings
        self._lock = threading.Lock()
        self.chunks: list[Document] = []
        self.vectors: FAISS | None = None
        self.bm25: BM25Okapi | None = None
        self.add(chunks)

    def add(self, chunks: list[Document]) -> None:
        if not chunks:
            return
        with self._lock:
            if self.vectors is None:
                self.vectors = FAISS.from_documents(chunks, self.embeddings, normalize_L2=True)
            else:
                self.vectors.add_documents(chunks)
            self.chunks = self.chunks + chunks
            self.bm25 = BM25Okapi([tokenize(c.page_content) for c in self.chunks])

    def search(self, query: str, k: int = 4, role: str = "technician", mode: str = "hybrid") -> list[Hit]:
        allowed = ROLE_ACCESS[role]
        depth = max(20, k * 5)
        with tracing.span("rag.search", mode=mode, k=k):
            vector_ranked: list[str] = []
            if mode in ("hybrid", "vector"):
                for doc, _ in self.vectors.similarity_search_with_score(query, k=depth):
                    vector_ranked.append(doc.metadata["chunk_id"])
            keyword_ranked: list[str] = []
            if mode in ("hybrid", "keyword"):
                scores = self.bm25.get_scores(tokenize(query))
                order = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:depth]
                keyword_ranked = [self.chunks[i].metadata["chunk_id"] for i in order if scores[i] > 0]

        by_id = {c.metadata["chunk_id"]: c for c in self.chunks}
        fused: dict[str, float] = {}
        for ranking in (vector_ranked, keyword_ranked):
            for rank, cid in enumerate(ranking):
                fused[cid] = fused.get(cid, 0.0) + 1.0 / (RRF_K + rank + 1)
        identifiers = {m.lower() for m in _IDENTIFIER.findall(query)} if mode == "hybrid" else set()
        for ident in identifiers:
            for cid, doc in by_id.items():
                if ident in doc.page_content.lower():
                    fused[cid] = fused.get(cid, 0.0) + 1.0  # exact match outranks any fused score
                if ident in doc.metadata["doc_id"].lower():
                    fused[cid] += 0.5  # the document itself beats documents that only mention it
        hits = []
        for cid, score in sorted(fused.items(), key=lambda kv: kv[1], reverse=True):
            doc = by_id[cid]
            if doc.metadata.get("access", "public") not in allowed:
                continue  # access control happens before the LLM ever sees the text
            hits.append(Hit(doc, score,
                            vector_ranked.index(cid) + 1 if cid in vector_ranked else None,
                            keyword_ranked.index(cid) + 1 if cid in keyword_ranked else None))
            if len(hits) == k:
                break
        return hits


def build(chunk_size: int = 700, chunk_overlap: int = 100, use_cache: bool = True) -> KnowledgeBase:
    start = time.perf_counter()
    kb = KnowledgeBase(split(load_directory(DOCS_DIR), chunk_size, chunk_overlap), CachedEmbeddings(use_cache))
    kb.build_seconds = time.perf_counter() - start
    return kb


@lru_cache
def get_kb() -> KnowledgeBase:
    return build()
