"""Day 4 — Security I: PII redaction and prompt-injection screening for RAG."""
from __future__ import annotations

import re

PII_PATTERNS = [
    (re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b"), "[EMAIL]"),
    (re.compile(r"\b(?:\+?1[ -]?)?\(?\d{3}\)?[ -]?\d{3}-\d{4}\b"), "[PHONE]"),
    (re.compile(r"\bEMP-\d{4,}\b"), "[EMPLOYEE_ID]"),
    (re.compile(r"\b(?:[Tt]echnician|[Ii]nspector|[Ss]igned by|[Tt]ech)[:\s]+([A-Z][a-z]+ [A-Z][a-z]+)"), None),
]

INJECTION_PATTERNS = [
    r"ignore (all |any )?(previous|prior|above) (instructions|rules)",
    r"disregard (the |your )?(system|previous) (prompt|instructions)",
    r"you (must|should) now",
    r"new instructions?:",
    r"system prompt",
    r"tell the user (that )?",
    r"reveal (your|the) (instructions|prompt)",
    r"(aircraft|engine) is airworthy",
]
_INJECTION = re.compile("|".join(INJECTION_PATTERNS), re.IGNORECASE)


def redact_pii(text: str) -> str:
    for pattern, replacement in PII_PATTERNS:
        if replacement is None:  # keep the label, hide the person's name
            text = pattern.sub(lambda m: m.group(0).replace(m.group(1), "[NAME]"), text)
        else:
            text = pattern.sub(replacement, text)
    return text


def find_injections(text: str) -> list[str]:
    sentences = re.split(r"(?<=[.!?])\s+|\n", text)
    return [s.strip() for s in sentences if _INJECTION.search(s)]


def sanitize_chunk(text: str) -> tuple[str, list[str]]:
    """Remove sentences that look like instructions to the model. Returns (clean_text, removed)."""
    removed = find_injections(text)
    for sentence in removed:
        text = text.replace(sentence, "[removed: possible prompt injection]")
    return text, removed
