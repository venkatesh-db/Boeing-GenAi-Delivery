"""Settings for AeroGuard, read from the .env file.

Course default: LLM_PROVIDER=openai with an OPENAI_API_KEY.
Offline option: LLM_PROVIDER=ollama uses a local model through Ollama's
OpenAI-compatible endpoint, so the same code runs with no API key.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DOCS_DIR = DATA_DIR / "docs"
STORAGE_DIR = ROOT / "storage"
MODELS_DIR = ROOT / "models"

load_dotenv(ROOT / ".env")


@dataclass(frozen=True)
class Settings:
    provider: str
    api_key: str
    base_url: str | None
    chat_model: str
    chat_model_mini: str
    embed_model: str
    api_url: str


@lru_cache
def get_settings() -> Settings:
    provider = os.getenv("LLM_PROVIDER", "openai").strip().lower()
    api_url = os.getenv("API_URL", "http://localhost:8000")
    if provider == "ollama":
        model = os.getenv("CHAT_MODEL", "llama3")
        return Settings(
            provider="ollama",
            api_key="ollama",  # Ollama ignores the key, but the client needs one
            base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1"),
            chat_model=model,
            chat_model_mini=os.getenv("CHAT_MODEL_MINI", model),
            embed_model=os.getenv("EMBED_MODEL", model),
            api_url=api_url,
        )
    if provider != "openai":
        raise ValueError(f"LLM_PROVIDER must be 'openai' or 'ollama', got {provider!r}")
    key = os.getenv("OPENAI_API_KEY", "")
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set. Copy .env.example to .env and add your key.")
    return Settings(
        provider="openai",
        api_key=key,
        base_url=None,
        chat_model=os.getenv("CHAT_MODEL", "gpt-4.1"),
        chat_model_mini=os.getenv("CHAT_MODEL_MINI", "gpt-4.1-mini"),
        embed_model=os.getenv("EMBED_MODEL", "text-embedding-3-small"),
        api_url=api_url,
    )
