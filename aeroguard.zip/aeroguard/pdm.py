"""Day 3 — predictive maintenance on C-MAPSS-format engine data.

ML predicts (remaining useful life and failure probability). The LLM only explains.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import mean_squared_error, precision_score, recall_score

from aeroguard.config import DATA_DIR, MODELS_DIR

CMAPSS = DATA_DIR / "cmapss"
MODEL_PATH = MODELS_DIR / "pdm.joblib"
COLUMNS = ["unit", "cycle", "setting1", "setting2", "setting3"] + [f"s{i}" for i in range(1, 22)]
SENSOR_NAMES = {
    "s2": "LPC outlet temperature (T24)", "s3": "HPC outlet temperature (T30)", "s4": "LPT outlet temperature (T50)",
    "s7": "HPC outlet pressure (P30)", "s8": "fan speed (Nf)", "s9": "core speed (Nc)",
    "s11": "HPC static pressure (Ps30)", "s12": "fuel flow ratio (phi)", "s13": "corrected fan speed",
    "s14": "corrected core speed", "s15": "bypass ratio", "s17": "bleed enthalpy",
    "s20": "HPT coolant bleed (W31)", "s21": "LPT coolant bleed (W32)",
}
SENSORS = list(SENSOR_NAMES)
WINDOW = 10
RUL_CAP = 125        # standard C-MAPSS practice: early life is treated as "healthy"
FAIL_HORIZON = 30    # classifier target: fails within 30 cycles


def load(name: str) -> pd.DataFrame:
    return pd.read_csv(CMAPSS / f"{name}_FD001.txt", sep=r"\s+", header=None, names=COLUMNS)


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Per engine: rolling mean (level), rolling std (spread) and trend (change of the mean over the window)."""
    grouped = df.groupby("unit")[SENSORS]
    means = grouped.rolling(WINDOW, min_periods=1).mean().reset_index(level=0, drop=True)
    stds = grouped.rolling(WINDOW, min_periods=2).std().reset_index(level=0, drop=True).fillna(0)
    trends = (means - means.groupby(df["unit"]).shift(WINDOW)).fillna(0)
    return pd.concat([df[["unit", "cycle"]], means.add_suffix("_mean"), stds.add_suffix("_std"),
                      trends.add_suffix("_trend")], axis=1)


def feature_columns() -> list[str]:
    return (["cycle"] + [f"{s}_mean" for s in SENSORS] + [f"{s}_std" for s in SENSORS]
            + [f"{s}_trend" for s in SENSORS])


@dataclass(frozen=True)
class TrainResult:
    rmse: float
    precision: float
    recall: float
    model_path: Path
    caught_failures: int = 0     # true positives: engines near failure that we flagged
    missed_failures: int = 0     # false negatives: the costliest error
    false_alarms: int = 0        # false positives: an extra inspection


def train() -> TrainResult:
    train_df = load("train")
    train_df["rul"] = train_df.groupby("unit")["cycle"].transform("max") - train_df["cycle"]
    feats = add_features(train_df)
    X = feats[feature_columns()]
    y_rul = train_df["rul"].clip(upper=RUL_CAP)
    y_fail = (train_df["rul"] <= FAIL_HORIZON).astype(int)

    reg = RandomForestRegressor(n_estimators=150, max_depth=12, n_jobs=-1, random_state=0).fit(X, y_rul)
    clf = RandomForestClassifier(n_estimators=150, max_depth=12, n_jobs=-1, class_weight="balanced",
                                 random_state=0).fit(X, y_fail)

    # Evaluate on the test engines: last observed cycle vs the true remaining life
    test_df = load("test")
    last = add_features(test_df).groupby("unit").tail(1)
    true_rul = np.loadtxt(CMAPSS / "RUL_FD001.txt")
    pred_rul = reg.predict(last[feature_columns()])
    true_fail = (true_rul <= FAIL_HORIZON).astype(int)
    pred_fail = clf.predict(last[feature_columns()])

    healthy = train_df[train_df["cycle"] <= 30][SENSORS]
    MODELS_DIR.mkdir(exist_ok=True)
    result = TrainResult(
        rmse=float(np.sqrt(mean_squared_error(np.minimum(true_rul, RUL_CAP), pred_rul))),
        precision=float(precision_score(true_fail, pred_fail, zero_division=0)),
        recall=float(recall_score(true_fail, pred_fail, zero_division=0)),
        model_path=MODEL_PATH,
        caught_failures=int(((pred_fail == 1) & (true_fail == 1)).sum()),
        missed_failures=int(((pred_fail == 0) & (true_fail == 1)).sum()),
        false_alarms=int(((pred_fail == 1) & (true_fail == 0)).sum()),
    )
    joblib.dump({"reg": reg, "clf": clf, "baseline_mean": healthy.mean(), "baseline_std": healthy.std(),
                 "metrics": result.__dict__ | {"model_path": str(MODEL_PATH)}}, MODEL_PATH)
    load_model.cache_clear()
    return result


@lru_cache
def load_model() -> dict:
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model not trained yet. Run: python labs/day3/lab3_5_train_pdm.py")
    return joblib.load(MODEL_PATH)


@lru_cache
def engines() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "engines.csv").set_index("engine_id")


@lru_cache
def _test_features() -> tuple[pd.DataFrame, pd.DataFrame]:
    raw = load("test")
    return raw, add_features(raw)


def predict(engine_id: str) -> dict:
    """Prediction plus the sensors that moved most from a healthy engine."""
    if engine_id not in engines().index:
        raise KeyError(engine_id)
    model = load_model()
    row = engines().loc[engine_id]
    raw, feats = _test_features()
    unit = int(row["cmapss_unit"])
    last = feats[feats["unit"] == unit].tail(1)
    rul = float(model["reg"].predict(last[feature_columns()])[0])
    prob = float(model["clf"].predict_proba(last[feature_columns()])[0][1])
    risk = "high" if prob >= 0.5 or rul <= FAIL_HORIZON else "medium" if rul <= 75 else "low"

    recent = raw[raw["unit"] == unit].tail(WINDOW)[SENSORS].mean()
    z = ((recent - model["baseline_mean"]) / model["baseline_std"].replace(0, 1)).abs().sort_values(ascending=False)
    drivers = [f"{SENSOR_NAMES[s]} is {z[s]:.1f} standard deviations from a healthy engine" for s in z.index[:3]]
    return {
        "engine_id": engine_id,
        "tail_number": str(row["tail_number"]),
        "cycles_observed": int(last["cycle"].iloc[0]),
        "predicted_rul_cycles": round(rul, 1),
        "failure_probability_30_cycles": round(prob, 3),
        "risk_level": risk,
        "drivers": drivers,
    }
