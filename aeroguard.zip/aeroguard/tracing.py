"""Local tracing and cost tracking (Day 5). Nothing leaves the laptop.

Spans go to storage/traces.jsonl through OpenTelemetry; every LLM call is
also summarised for the cost and latency table at GET /metrics.
"""
from __future__ import annotations

import json
import os
import threading
from contextlib import contextmanager
from typing import Iterator, Sequence

from opentelemetry import trace
from opentelemetry.sdk.trace import ReadableSpan, TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, SpanExporter, SpanExportResult

from aeroguard.config import STORAGE_DIR

# USD per 1M tokens (input, output). Edit to match your provider's price list.
PRICES = {
    "gpt-4.1": (2.00, 8.00),
    "gpt-4.1-mini": (0.40, 1.60),
}

TRACE_FILE = STORAGE_DIR / "traces.jsonl"


class JsonlFileExporter(SpanExporter):
    def __init__(self, path):
        self.path = path
        self._lock = threading.Lock()

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock, open(self.path, "a", encoding="utf-8") as f:
            for s in spans:
                f.write(json.dumps({
                    "name": s.name,
                    "trace_id": format(s.context.trace_id, "032x"),
                    "duration_ms": round((s.end_time - s.start_time) / 1e6, 1),
                    "attributes": dict(s.attributes or {}),
                }) + "\n")
        return SpanExportResult.SUCCESS


_provider = TracerProvider()
if os.getenv("AEROGUARD_TRACING", "1") == "1":
    _provider.add_span_processor(SimpleSpanProcessor(JsonlFileExporter(TRACE_FILE)))
_tracer = _provider.get_tracer("aeroguard")


@contextmanager
def span(name: str, **attributes) -> Iterator[None]:
    with _tracer.start_as_current_span(name) as s:
        for k, v in attributes.items():
            s.set_attribute(k, v if isinstance(v, (str, int, float, bool)) else str(v))
        yield


_calls: list[dict] = []
_calls_lock = threading.Lock()


def cost_usd(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    price_in, price_out = PRICES.get(model, (0.0, 0.0))
    return (prompt_tokens * price_in + completion_tokens * price_out) / 1_000_000


def record_llm_call(c) -> None:
    with _calls_lock:
        _calls.append({
            "model": c.model,
            "prompt_tokens": c.prompt_tokens,
            "completion_tokens": c.completion_tokens,
            "latency_ms": round(c.latency_ms, 1),
            "cost_usd": cost_usd(c.model, c.prompt_tokens, c.completion_tokens),
            "cached": c.cached,
        })


def metrics_summary() -> dict:
    with _calls_lock:
        calls = list(_calls)
    live = [c for c in calls if not c["cached"]]
    latencies = sorted(c["latency_ms"] for c in live if c["latency_ms"] > 0)  # LangChain calls are timed by spans

    def pct(p: float) -> float:
        return latencies[min(len(latencies) - 1, int(p * len(latencies)))] if latencies else 0.0

    return {
        "llm_calls": len(calls),
        "cache_hits": len(calls) - len(live),
        "prompt_tokens": sum(c["prompt_tokens"] for c in calls),
        "completion_tokens": sum(c["completion_tokens"] for c in calls),
        "total_cost_usd": round(sum(c["cost_usd"] for c in calls), 6),
        "latency_p50_ms": pct(0.5),
        "latency_p95_ms": pct(0.95),
    }


def reset_metrics() -> None:
    with _calls_lock:
        _calls.clear()
