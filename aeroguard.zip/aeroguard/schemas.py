"""API contracts shared by the backend and the UI (Days 2–5)."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

TAIL_PATTERN = r"^N[0-9]{1,5}[A-Z]{0,2}$"
ENGINE_PATTERN = r"^N[0-9]{1,5}[A-Z]{0,2}-E[1-4]$"
MAX_MESSAGE = 4000

Role = Literal["technician", "inspector"]


class ErrorBody(BaseModel):
    code: str
    message: str


class ErrorResponse(BaseModel):
    error: ErrorBody


# ---------------- Day 2: chat
class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=MAX_MESSAGE)
    session_id: str | None = Field(default=None, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    tail_number: str | None = Field(default=None, pattern=TAIL_PATTERN)


class ChatResponse(BaseModel):
    answer: str
    model: str
    session_id: str | None = None


# ---------------- Day 3: structured defect records
class DefectRecord(BaseModel):
    tail_number: str | None = Field(default=None, description="Aircraft registration, e.g. N123AB, if mentioned")
    ata_chapter: int = Field(ge=0, le=99, description="ATA chapter number of the affected system")
    component: str = Field(min_length=2, description="Affected component")
    severity: Literal["minor", "major", "critical"]
    mel_deferrable: bool = Field(description="True if the item could normally be deferred under the MEL")
    recommended_action: str = Field(min_length=5, description="Next maintenance step, advisory only")


class ParseDefectRequest(BaseModel):
    text: str = Field(min_length=5, max_length=MAX_MESSAGE)


# ---------------- Day 3: predictive maintenance
class FailurePrediction(BaseModel):
    engine_id: str
    tail_number: str
    cycles_observed: int
    predicted_rul_cycles: float
    failure_probability_30_cycles: float
    risk_level: Literal["low", "medium", "high"]


class RiskExplanation(BaseModel):
    summary: str = Field(description="Two or three plain-language sentences for an engineer")
    main_drivers: list[str] = Field(description="Sensor trends or facts that drive the risk")
    recommended_next_check: str


class RiskReport(BaseModel):
    prediction: FailurePrediction
    explanation: RiskExplanation
    disclaimer: str = "Advisory only. A certificated person must make all airworthiness decisions."


# ---------------- Day 4: RAG
class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=MAX_MESSAGE)
    role: Role = "technician"
    top_k: int = Field(default=4, ge=1, le=10)


class Citation(BaseModel):
    source_id: str
    doc_id: str
    snippet: str


class AskResponse(BaseModel):
    answer: str
    citations: list[Citation]
    answered: bool
    warnings: list[str] = []
    retrieval_ms: float


# ---------------- Day 5: agent
class AgentRequest(BaseModel):
    question: str = Field(min_length=3, max_length=MAX_MESSAGE)
    role: Role = "technician"
    thread_id: str | None = Field(default=None, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")


class ApprovalRequest(BaseModel):
    thread_id: str = Field(max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    approve: bool
    role: Role
    approver: str = Field(min_length=2, max_length=80)


class WorkOrder(BaseModel):
    work_order_id: str
    tail_number: str
    engine_id: str | None
    title: str
    tasks: list[str]
    references: list[str]
    status: Literal["draft", "approved", "rejected"]


class AgentResponse(BaseModel):
    thread_id: str
    report: str
    steps: list[str]
    citations: list[Citation] = []
    work_order: WorkOrder | None = None
    pending_approval: bool = False
