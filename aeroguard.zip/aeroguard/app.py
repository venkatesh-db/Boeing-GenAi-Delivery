"""FastAPI application factory. Each course day adds routers to the same app.

Run a given day:
    AEROGUARD_DAY=2 uvicorn aeroguard.app:app --reload
(or use the thin entry points in api/day2.py ... api/day5.py)
"""
from __future__ import annotations

import logging
import os

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from aeroguard import tracing

log = logging.getLogger("aeroguard")


def _error(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


MAX_BODY_BYTES = 64 * 1024


def create_app(day: int = 5) -> FastAPI:
    if not 2 <= day <= 5:
        raise ValueError("day must be between 2 and 5")
    app = FastAPI(title=f"AeroGuard API (Day {day})", version=f"0.{day}.0")

    # Day 3: reject oversized requests before they are even parsed (uploads have their own limit on Day 4)
    @app.middleware("http")
    async def limit_body_size(request: Request, call_next):
        size = request.headers.get("content-length")
        if size and size.isdigit() and int(size) > MAX_BODY_BYTES and not request.url.path.startswith("/upload"):
            return _error(413, "payload_too_large", f"Request body is over {MAX_BODY_BYTES // 1024} KB")
        return await call_next(request)

    # Day 3: one consistent error shape for every failure
    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, exc: RequestValidationError) -> JSONResponse:
        first = exc.errors()[0]
        where = ".".join(str(p) for p in first["loc"] if p != "body")
        return _error(422, "invalid_input", f"{where}: {first['msg']}")

    @app.exception_handler(HTTPException)
    async def http_error(_: Request, exc: HTTPException) -> JSONResponse:
        return _error(exc.status_code, "request_error", str(exc.detail))

    @app.exception_handler(Exception)
    async def unexpected_error(_: Request, exc: Exception) -> JSONResponse:
        log.exception("unhandled error")
        return _error(500, "internal_error", "Something went wrong. Check the server log.")

    @app.get("/health")
    def health() -> dict:
        return {"status": "ok", "day": day}

    from aeroguard.routers import chat, fleet
    app.include_router(fleet.router)
    app.include_router(chat.router)

    if day >= 3:
        from aeroguard.routers import defects, pdm, sessions
        app.include_router(sessions.router)
        app.include_router(defects.router)
        app.include_router(pdm.router)

    if day >= 4:
        from aeroguard.routers import rag
        app.include_router(rag.router)

    if day >= 5:
        from aeroguard.routers import agent
        app.include_router(agent.router)

        @app.get("/metrics")
        def metrics() -> dict:
            return tracing.metrics_summary()

    return app


def __getattr__(name: str) -> FastAPI:
    """`uvicorn aeroguard.app:app` builds the app for AEROGUARD_DAY only when asked for."""
    if name == "app":
        return create_app(int(os.getenv("AEROGUARD_DAY", "5")))
    raise AttributeError(name)
