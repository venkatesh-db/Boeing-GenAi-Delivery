"""Day 4 — Milestone 3: POST /upload and POST /ask."""
from __future__ import annotations

import re
from pathlib import Path

from fastapi import APIRouter, HTTPException, UploadFile

from aeroguard.config import STORAGE_DIR
from aeroguard.rag import guardrails
from aeroguard.rag.ingest import ALLOWED_SUFFIXES, load_file, split
from aeroguard.rag.qa import answer
from aeroguard.rag.store import get_kb
from aeroguard.schemas import AskRequest, AskResponse

router = APIRouter(tags=["Day 4 - RAG"])
MAX_UPLOAD_BYTES = 2 * 1024 * 1024
UPLOAD_DIR = STORAGE_DIR / "uploads"


@router.post("/upload")
async def upload(file: UploadFile) -> dict:
    name = re.sub(r"[^A-Za-z0-9._-]", "_", Path(file.filename or "upload.txt").name)
    if Path(name).suffix.lower() not in ALLOWED_SUFFIXES:
        raise HTTPException(status_code=415, detail=f"Only {sorted(ALLOWED_SUFFIXES)} files are accepted")
    data = await file.read()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File is larger than 2 MB")
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    path = UPLOAD_DIR / name
    path.write_bytes(data)

    docs = load_file(path, default_access="public")
    suspicious = guardrails.find_injections(docs[0].page_content)
    chunks = split(docs)
    for chunk in chunks:
        chunk.metadata["chunk_id"] = f"upload:{chunk.metadata['chunk_id']}"
    get_kb().add(chunks)
    warnings = [f"Possible prompt injection: {s[:120]}" for s in suspicious]
    return {"filename": name, "chunks": len(chunks), "warnings": warnings}


@router.post("/ask", response_model=AskResponse)
def ask(req: AskRequest) -> AskResponse:
    return answer(req.question, role=req.role, k=req.top_k)
