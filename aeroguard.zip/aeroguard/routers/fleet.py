"""Day 2 — Lab 2.3 FastAPI basics: a path parameter, validation and a typed response."""
from fastapi import APIRouter, HTTPException, Path
from pydantic import BaseModel

from aeroguard import records
from aeroguard.schemas import TAIL_PATTERN

router = APIRouter(tags=["Day 2 - fleet"])


class Aircraft(BaseModel):
    tail_number: str
    model: str
    engine_type: str
    delivery_year: int
    flight_hours: int
    flight_cycles: int
    base: str


@router.get("/aircraft/{tail_number}", response_model=Aircraft)
def get_aircraft(tail_number: str = Path(pattern=TAIL_PATTERN, examples=["N123AB"])) -> Aircraft:
    found = records.aircraft(tail_number)
    if not found:
        raise HTTPException(status_code=404, detail=f"Unknown aircraft {tail_number}")
    return Aircraft(**found)
