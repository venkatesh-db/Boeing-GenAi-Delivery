"""Day 3 — POST /parse-defect: free-text squawk -> validated DefectRecord."""
import re

from fastapi import APIRouter, HTTPException

from aeroguard import llm
from aeroguard.prompts import DEFECT_PARSER
from aeroguard.schemas import DefectRecord, ParseDefectRequest

router = APIRouter(tags=["Day 3 - structured output"])

_TAIL = re.compile(r"\bN[0-9]{1,5}[A-Z]{0,2}\b")


def parse_defect(text: str) -> DefectRecord:
    record = llm.chat_json(
        [{"role": "system", "content": DEFECT_PARSER}, {"role": "user", "content": text}], DefectRecord
    )
    # Facts we can read directly from the text beat the model's guess.
    found = _TAIL.search(text.upper())
    return record.model_copy(update={"tail_number": found.group() if found else None})


@router.post("/parse-defect", response_model=DefectRecord)
def parse(req: ParseDefectRequest) -> DefectRecord:
    try:
        return parse_defect(req.text)
    except ValueError as err:
        raise HTTPException(status_code=502, detail=f"The model could not produce a valid record: {err}") from err
