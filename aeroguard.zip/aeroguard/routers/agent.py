"""Day 5 — Milestone 4: POST /agent/run and POST /agent/approve (human-in-the-loop)."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, HTTPException
from langgraph.types import Command

from aeroguard import security
from aeroguard.agent.graph import get_graph
from aeroguard.schemas import AgentRequest, AgentResponse, ApprovalRequest, Citation, WorkOrder

router = APIRouter(tags=["Day 5 - agent"])


def _response(thread_id: str) -> AgentResponse:
    snapshot = get_graph().get_state({"configurable": {"thread_id": thread_id}})
    values = snapshot.values
    work_order = values.get("work_order")
    return AgentResponse(
        thread_id=thread_id,
        report=values.get("report", ""),
        steps=values.get("steps", []),
        citations=[Citation(**c) for c in values.get("citations", [])],
        work_order=WorkOrder(**work_order) if work_order else None,
        pending_approval=bool(snapshot.next),
    )


@router.post("/agent/run", response_model=AgentResponse)
def run(req: AgentRequest) -> AgentResponse:
    try:
        security.require(req.role, "run_agent")
    except security.PermissionDenied as err:
        raise HTTPException(status_code=403, detail=str(err)) from None
    thread_id = req.thread_id or uuid.uuid4().hex[:12]
    security.audit("agent_run", thread_id=thread_id, role=req.role, question=req.question[:200])
    get_graph().invoke({"question": req.question, "role": req.role, "thread_id": thread_id},
                       {"configurable": {"thread_id": thread_id}, "recursion_limit": 25})
    return _response(thread_id)


@router.post("/agent/approve", response_model=AgentResponse)
def approve(req: ApprovalRequest) -> AgentResponse:
    try:
        security.require(req.role, "approve_work_order")
    except security.PermissionDenied as err:
        security.audit("approval_denied", thread_id=req.thread_id, role=req.role, approver=req.approver)
        raise HTTPException(status_code=403, detail=str(err)) from None
    config = {"configurable": {"thread_id": req.thread_id}}
    if not get_graph().get_state(config).next:
        raise HTTPException(status_code=409, detail="Nothing is waiting for approval on this thread")
    get_graph().invoke(Command(resume={"approve": req.approve, "approver": req.approver, "role": req.role}), config)
    return _response(req.thread_id)


@router.get("/agent/audit")
def audit_log(thread_id: str | None = None) -> list[dict]:
    return security.read_audit(thread_id)
