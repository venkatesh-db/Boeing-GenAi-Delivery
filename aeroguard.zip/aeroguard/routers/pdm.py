"""Day 3 — GET /predict-failure/{engine_id}: ML prediction + LLM explanation."""
from fastapi import APIRouter, HTTPException, Path

from aeroguard import llm, pdm, safety
from aeroguard.prompts import RISK_EXPLAINER
from aeroguard.schemas import ENGINE_PATTERN, FailurePrediction, RiskExplanation, RiskReport

router = APIRouter(tags=["Day 3 - predictive maintenance"])


def risk_report(engine_id: str) -> RiskReport:
    result = pdm.predict(engine_id)
    prediction = FailurePrediction(**{k: v for k, v in result.items() if k != "drivers"})
    facts = prediction.model_dump() | {"sensor_trends": result["drivers"]}
    explanation = llm.chat_json(
        [{"role": "system", "content": RISK_EXPLAINER},
         {"role": "user", "content": f"Prediction for engine {engine_id}:\n{facts}"}],
        RiskExplanation,
    )
    safe_summary = safety.enforce_advisory("", explanation.summary)
    # The numbers always come from the model, never from the LLM.
    return RiskReport(prediction=prediction, explanation=explanation.model_copy(update={"summary": safe_summary}))


@router.get("/predict-failure/{engine_id}", response_model=RiskReport)
def predict_failure(engine_id: str = Path(pattern=ENGINE_PATTERN)) -> RiskReport:
    try:
        return risk_report(engine_id)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Unknown engine {engine_id}") from None
    except FileNotFoundError as err:
        raise HTTPException(status_code=503, detail=str(err)) from None
    except ValueError as err:
        raise HTTPException(status_code=502, detail=f"Explanation failed: {err}") from err
