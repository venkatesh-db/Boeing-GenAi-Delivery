"""Day 2 — Milestone 1: POST /chat calls the LLM with the maintenance-assistant prompt."""
from fastapi import APIRouter

from aeroguard import llm, safety
from aeroguard.config import get_settings
from aeroguard.prompts import MAINTENANCE_ASSISTANT
from aeroguard.schemas import ChatRequest, ChatResponse

router = APIRouter(tags=["Day 2 - chat"])


@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    context = f"Aircraft: {req.tail_number}\n" if req.tail_number else ""
    messages = [
        {"role": "system", "content": MAINTENANCE_ASSISTANT},
        {"role": "user", "content": context + req.message},
    ]
    model = get_settings().chat_model
    if safety.asks_for_decision(req.message):
        return ChatResponse(answer=safety.REFUSAL, model="guardrail")
    answer = safety.enforce_advisory(req.message, llm.chat(messages, model=model))
    return ChatResponse(answer=answer, model=model)
