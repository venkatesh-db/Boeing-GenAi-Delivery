"""Day 3 — conversation memory per session (and aircraft) plus streaming (Milestone 2)."""
from __future__ import annotations

import json
import threading
import uuid
from typing import Iterator

from fastapi import APIRouter
from sse_starlette.sse import EventSourceResponse

from aeroguard import llm, safety
from aeroguard.config import get_settings
from aeroguard.prompts import MAINTENANCE_ASSISTANT
from aeroguard.schemas import ChatRequest, ChatResponse

router = APIRouter(tags=["Day 3 - sessions & streaming"])

MAX_TURNS = 10          # keep the last 10 user/assistant pairs
MAX_HISTORY_CHARS = 12_000  # rough guard so history fits the context window

_sessions: dict[str, list[dict]] = {}
_lock = threading.Lock()


def _key(session_id: str, tail_number: str | None) -> str:
    """One history per session AND aircraft: switching tail number never mixes two aircraft."""
    return f"{session_id}:{tail_number or '-'}"


def _history(key: str) -> list[dict]:
    with _lock:
        return list(_sessions.get(key, []))


def _save_turn(key: str, user: str, assistant: str) -> None:
    with _lock:
        turns = _sessions.get(key, []) + [
            {"role": "user", "content": user},
            {"role": "assistant", "content": assistant},
        ]
        turns = turns[-MAX_TURNS * 2:]
        while sum(len(m["content"]) for m in turns) > MAX_HISTORY_CHARS and len(turns) > 2:
            turns = turns[2:]
        _sessions[key] = turns


def _messages(req: ChatRequest, session_id: str) -> list[dict]:
    system = MAINTENANCE_ASSISTANT
    if req.tail_number:
        system += f"\n\nThis troubleshooting session is about aircraft {req.tail_number}."
    history = _history(_key(session_id, req.tail_number))
    return [{"role": "system", "content": system}, *history, {"role": "user", "content": req.message}]


@router.post("/chat/session", response_model=ChatResponse)
def chat_with_memory(req: ChatRequest) -> ChatResponse:
    session_id = req.session_id or uuid.uuid4().hex[:12]
    model = get_settings().chat_model
    if safety.asks_for_decision(req.message):
        answer, model = safety.REFUSAL, "guardrail"
    else:
        answer = safety.enforce_advisory(req.message, llm.chat(_messages(req, session_id), model=model))
    _save_turn(_key(session_id, req.tail_number), req.message, answer)
    return ChatResponse(answer=answer, model=model, session_id=session_id)


@router.post("/chat/stream")
def chat_stream(req: ChatRequest) -> EventSourceResponse:
    """Server-sent events: {"delta": "..."} pieces, then {"done": true, "session_id": ...}."""
    session_id = req.session_id or uuid.uuid4().hex[:12]

    def events() -> Iterator[dict]:
        if safety.asks_for_decision(req.message):
            pieces: Iterator[str] = iter([safety.REFUSAL])
        else:
            pieces = llm.chat_stream(_messages(req, session_id))
        parts: list[str] = []
        try:
            for piece in pieces:
                parts.append(piece)
                yield {"data": json.dumps({"delta": piece})}
        except Exception as err:  # report the failure to the UI instead of dropping the stream
            yield {"data": json.dumps({"delta": f"\n[stream error: {type(err).__name__}]"})}
        _save_turn(_key(session_id, req.tail_number), req.message, "".join(parts))
        yield {"data": json.dumps({"done": True, "session_id": session_id})}

    return EventSourceResponse(events())
