"""Day 2 safety rule, enforced in code: the assistant never makes airworthiness decisions.

A system prompt asks the model to behave, but models do not always comply.
This check runs on every question and answer, whatever the model said.
"""
from __future__ import annotations

import re

_DECISION_QUESTION = re.compile(
    r"\b(airworthy|airworthiness|safe to (fly|dispatch|release)|ok to (fly|dispatch)|release (it|the aircraft)"
    r"|return(ed)? to service|back (in)?to service|release\b.{0,30}\bservice|sign (it )?off|sign off\b"
    r"|ok to (fly|dispatch)|dispatch (it|the aircraft|N[0-9][0-9A-Z]{0,4})|go or no.?go)\b",
    re.IGNORECASE,
)
_DECISION_ANSWER = re.compile(
    r"\b(is|are) (airworthy|safe to fly|serviceable)\b|\bcleared for (flight|release)\b|\bapproved? for return to service\b",
    re.IGNORECASE,
)

REFUSAL = (
    "I can't make airworthiness or return-to-service decisions. A certificated person must decide, "
    "using the maintenance manual, the MEL and the aircraft records. I can help you find the relevant "
    "procedure, directives or past write-ups."
)


def asks_for_decision(question: str) -> bool:
    return bool(_DECISION_QUESTION.search(question))


_HEDGE = re.compile(r"\b(if|whether|certificated|cannot|can't|not|never|must decide)\b", re.IGNORECASE)


def claims_airworthiness(answer: str) -> bool:
    """True if a sentence asserts airworthiness. Hedged or negated sentences
    ("a certificated person must decide if it is safe to fly") are allowed."""
    for sentence in re.split(r"(?<=[.!?])\s+|\n", answer):
        if _DECISION_ANSWER.search(sentence) and not _HEDGE.search(sentence):
            return True
    return False


def enforce_advisory(question: str, answer: str) -> str:
    """Return a safe answer: refuse decision questions, and block answers that claim airworthiness."""
    if asks_for_decision(question) or claims_airworthiness(answer):
        return REFUSAL
    return answer
