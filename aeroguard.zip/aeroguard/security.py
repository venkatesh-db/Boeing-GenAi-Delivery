"""Day 5 — Security II: roles, tool allowlist and an append-only audit log."""
from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone

from aeroguard.config import STORAGE_DIR

AUDIT_FILE = STORAGE_DIR / "audit.jsonl"

PERMISSIONS = {
    "technician": {"run_agent", "draft_work_order"},
    "inspector": {"run_agent", "draft_work_order", "approve_work_order", "read_restricted"},
}

# The agent may only ever call these tools. Nothing here can close a work order or sign off an aircraft.
TOOL_ALLOWLIST = {"predict_failure", "search_documents", "get_maintenance_history", "check_compliance"}

_lock = threading.Lock()


def safe_mode() -> bool:
    """AEROGUARD_SAFE_MODE=1 makes the agent read-only: it reports, but takes no action (no work orders)."""
    return os.getenv("AEROGUARD_SAFE_MODE", "0") == "1"


class PermissionDenied(Exception):
    pass


def require(role: str, permission: str) -> None:
    if permission not in PERMISSIONS.get(role, set()):
        audit("permission_denied", role=role, permission=permission)
        raise PermissionDenied(f"role '{role}' is not allowed to {permission.replace('_', ' ')}")


def check_tool(name: str) -> None:
    if name not in TOOL_ALLOWLIST:
        audit("tool_blocked", tool=name)
        raise PermissionDenied(f"tool '{name}' is not on the allowlist")


def audit(event: str, **fields) -> None:
    record = {"time": datetime.now(timezone.utc).isoformat(timespec="seconds"), "event": event, **fields}
    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with _lock, open(AUDIT_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, default=str) + "\n")


def read_audit(thread_id: str | None = None, limit: int = 50) -> list[dict]:
    if not AUDIT_FILE.exists():
        return []
    rows = [json.loads(line) for line in AUDIT_FILE.read_text().splitlines() if line.strip()]
    if thread_id:
        rows = [r for r in rows if r.get("thread_id") == thread_id]
    return rows[-limit:]
