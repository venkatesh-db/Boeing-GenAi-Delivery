"""Day 5 — connect to the records MCP server and call its tools (langchain-mcp-adapters)."""
from __future__ import annotations

import asyncio
import json
import os
import sys

from langchain_mcp_adapters.client import MultiServerMCPClient

from aeroguard import tracing
from aeroguard.config import ROOT


def _client() -> MultiServerMCPClient:
    return MultiServerMCPClient({
        "records": {
            "transport": "stdio",
            "command": sys.executable,
            "args": [str(ROOT / "mcp_server" / "server.py")],
            "env": {"MCP_ACCESS_TOKEN": os.getenv("MCP_ACCESS_TOKEN", ""), "PATH": os.getenv("PATH", "")},
        }
    })


async def _call(name: str, args: dict):
    tools = {t.name: t for t in await _client().get_tools()}
    result = _decode(await tools[name].ainvoke(args | {"access_token": os.getenv("MCP_ACCESS_TOKEN", "")}))
    if isinstance(result, str) and result.startswith("Error executing tool"):
        raise RuntimeError(result)
    return result


def _decode(result):
    """Tool results arrive as text or content blocks; return plain Python data."""
    if isinstance(result, list):
        texts = [b.get("text", "") if isinstance(b, dict) else str(b) for b in result]
        decoded = [_decode(t) for t in texts]
        return decoded[0] if len(decoded) == 1 else decoded
    if isinstance(result, str):
        try:
            return json.loads(result)
        except json.JSONDecodeError:
            return result
    return result


def call_tool(name: str, args: dict):
    """Synchronous wrapper used by the LangGraph agent."""
    with tracing.span("mcp.call_tool", tool=name):
        return asyncio.run(_call(name, args))


async def list_tools() -> list[str]:
    return [t.name for t in await _client().get_tools()]
