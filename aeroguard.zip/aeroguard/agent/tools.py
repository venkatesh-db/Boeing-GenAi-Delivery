"""Day 5 — the agent's tools. Each one is small, validated and on the security allowlist."""
from __future__ import annotations

from langchain_core.tools import tool

from aeroguard import pdm, security
from aeroguard.agent.mcp_client import call_tool
from aeroguard.rag.store import get_kb


@tool
def predict_failure(engine_id: str) -> dict:
    """Predict remaining useful life and 30-cycle failure probability for an engine id like N123AB-E2."""
    security.check_tool("predict_failure")
    return pdm.predict(engine_id)


def search_for_role(query: str, role: str) -> list[dict]:
    """Internal: the agent passes the caller's real role. Never exposed to the LLM."""
    security.check_tool("search_documents")
    return [{"doc_id": h.doc.metadata["doc_id"], "text": h.doc.page_content[:600]}
            for h in get_kb().search(query, k=3, role=role)]


@tool
def search_documents(query: str) -> list[dict]:
    """Search airworthiness directives, regulations and maintenance manual pages. Returns cited snippets."""
    # The role is NOT a tool argument: an LLM-chosen role would let a prompt unlock restricted documents.
    return search_for_role(query, role="technician")


@tool
def get_maintenance_history(tail_number: str, ata_chapter: int | None = None) -> list[dict]:
    """Recent maintenance write-ups for an aircraft (from the records MCP server)."""
    security.check_tool("get_maintenance_history")
    args = {"tail_number": tail_number, "limit": 8}
    if ata_chapter is not None:
        args["ata_chapter"] = ata_chapter
    result = call_tool("get_maintenance_history", args)
    return result if isinstance(result, list) else [result]


@tool
def check_compliance(tail_number: str) -> dict:
    """Applicable airworthiness directives for an aircraft and which are still open (MCP server)."""
    security.check_tool("check_compliance")
    status = call_tool("get_ad_status", {"tail_number": tail_number})
    status = status if isinstance(status, list) else [status]
    return {"tail_number": tail_number, "open": [s for s in status if s["status"] == "open"],
            "complied": [s for s in status if s["status"] == "complied"]}


TOOLS = {t.name: t for t in (predict_failure, search_documents, get_maintenance_history, check_compliance)}
