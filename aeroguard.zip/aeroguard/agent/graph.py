"""Day 5 — the AeroGuard agent as a LangGraph planner–executor graph.

plan ──► execute ⟲ (one tool per step, stop after MAX_STEPS) ──► report ──► draft_work_order ──► approval (human)
  └──► answer_direct (no tools needed, cheaper model)            └──► END (nothing to act on)
"""
from __future__ import annotations

import re
import sqlite3
import uuid
from functools import lru_cache
from typing import Any, Literal, TypedDict

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt
from pydantic import BaseModel, Field

from aeroguard import llm, safety, security, tracing
from aeroguard.agent.tools import TOOLS, search_for_role
from aeroguard.config import STORAGE_DIR, get_settings
from aeroguard.prompts import MAINTENANCE_ASSISTANT

MAX_STEPS = 6  # stop criterion: the agent can never loop forever
# Compliance runs before the search, so the search can look up the open ADs by their exact numbers.
STEP_ORDER = ["predict_failure", "get_maintenance_history", "check_compliance", "search_documents"]
_TAIL = re.compile(r"\bN[0-9]{1,5}[A-Z]{0,2}\b")
_ENGINE = re.compile(r"\b(?:engine|eng|#)\s*([1-4])\b|\bE([1-4])\b", re.IGNORECASE)

PLANNER = """ROLE: You plan the steps for an aircraft maintenance assistant.

TASK: Decide which tools are needed to answer the question.
Tools: predict_failure (engine health / risk / remaining life), get_maintenance_history (past write-ups),
search_documents (manuals, airworthiness directives, regulations), check_compliance (open ADs for an aircraft).

CONSTRAINTS: Use direct_answer=true only for general questions that need no aircraft data or documents."""

REPORTER = """ROLE: You write a short engineering report for a maintenance team.

TASK: Using ONLY the facts given, write markdown with these headings:
### History, ### Evidence, ### Compliance, ### Recommendation.
(The Risk section with the model's numbers is written separately - do not repeat the numbers.)

CONSTRAINTS:
- The Evidence and Compliance sections MUST cite documents as [S1], [S2] exactly as labelled in "documents".
  Example: "Inspect the fan blades before further flight [S3]."
- Do not change any number. Do not invent facts.
- Advisory only: never say the aircraft or engine is airworthy; a certificated person decides."""


class Plan(BaseModel):
    tail_number: str | None = Field(default=None, description="Aircraft registration such as N123AB")
    engine_number: int | None = Field(default=None, description="Engine position 1-4 if mentioned")
    steps: list[Literal["predict_failure", "get_maintenance_history", "search_documents", "check_compliance"]] = []
    direct_answer: bool = Field(default=False, description="True if no tools are needed")


class AgentState(TypedDict, total=False):
    thread_id: str
    question: str
    role: str
    tail_number: str | None
    engine_id: str | None
    plan: list[str]
    steps: list[str]
    results: dict[str, Any]
    report: str
    citations: list[dict]
    work_order: dict | None
    decision: dict | None


# ---------------------------------------------------------------- nodes
def plan_node(state: AgentState) -> AgentState:
    question = state["question"]
    try:
        plan = llm.chat_json([{"role": "system", "content": PLANNER}, {"role": "user", "content": question}], Plan,
                             use_cache=True)
    except ValueError:
        plan = Plan(steps=list(STEP_ORDER))  # safe default: gather everything
    # Facts we can read from the text override the model's guess.
    tail_match = _TAIL.search(question.upper())
    tail = tail_match.group() if tail_match else None
    engine_match = _ENGINE.search(question)
    engine_no = int(next(g for g in engine_match.groups() if g)) if engine_match else plan.engine_number
    engine_id = f"{tail}-E{engine_no}" if tail and engine_no else None

    steps = set(plan.steps)
    if engine_id:
        steps.add("predict_failure")
    if tail:
        steps |= {"get_maintenance_history", "check_compliance"}
    if not engine_id:
        steps.discard("predict_failure")
    if not tail:
        steps -= {"get_maintenance_history", "check_compliance"}
    if steps and "search_documents" not in steps:
        steps.add("search_documents")  # every data answer should be backed by documents
    ordered = [s for s in STEP_ORDER if s in steps]
    direct = not ordered
    security.audit("agent_plan", thread_id=state.get("thread_id"), steps=ordered, direct=direct)
    return {"tail_number": tail, "engine_id": engine_id, "plan": ordered, "results": {},
            "steps": ["plan: " + (", ".join(ordered) if ordered else "answer directly")]}


def execute_node(state: AgentState) -> AgentState:
    step = state["plan"][0]
    security.check_tool(step)  # allowlist: anything else is blocked and audited
    tool = TOOLS[step]
    results = dict(state["results"])
    try:
        if step == "predict_failure":
            results[step] = tool.invoke({"engine_id": state["engine_id"]})
        elif step == "get_maintenance_history":
            results[step] = tool.invoke({"tail_number": state["tail_number"],
                                         "ata_chapter": 72 if state.get("engine_id") else None})
        elif step == "search_documents":
            query = state["question"]
            if results.get("predict_failure"):
                query += " AMM 72-00-00 engine vibration troubleshooting inspection"
            open_ads = (results.get("check_compliance") or {}).get("open", [])
            query += " " + " ".join(ad["ad_number"] for ad in open_ads)
            results[step] = search_for_role(query, state["role"])
        elif step == "check_compliance":
            results[step] = tool.invoke({"tail_number": state["tail_number"]})
        status = "ok"
    except Exception as err:  # a failed tool is reported, not fatal
        results[step] = {"error": f"{type(err).__name__}: {err}"}
        status = "failed"
    security.audit("tool_call", thread_id=state.get("thread_id"), tool=step, status=status, role=state["role"])
    return {"plan": state["plan"][1:], "results": results, "steps": state["steps"] + [f"{step}: {status}"]}


def _risk_section(prediction: dict | None) -> str:
    """Written by code, not the LLM: the ML model's numbers appear exactly as predicted."""
    if not prediction or "error" in prediction:
        return ""
    drivers = "\n".join(f"- {d}" for d in prediction.get("drivers", []))
    return (f"### Risk\n**{prediction['risk_level'].upper()}** for {prediction['engine_id']}: predicted remaining life "
            f"{prediction['predicted_rul_cycles']} cycles, failure probability within 30 cycles "
            f"{prediction['failure_probability_30_cycles']:.0%} (ML model, {prediction['cycles_observed']} cycles observed)."
            f"\n{drivers}\n\n")


def report_node(state: AgentState) -> AgentState:
    results = state["results"]
    docs = results.get("search_documents") or []
    docs = docs if isinstance(docs, list) else []
    sources = {f"S{i}": d for i, d in enumerate(docs, start=1)}
    facts = {
        "question": state["question"],
        "prediction (from the ML model)": results.get("predict_failure"),
        "maintenance_history": results.get("get_maintenance_history"),
        "ad_compliance": results.get("check_compliance"),
        "documents": {sid: f"{d['doc_id']}: {d['text'][:400]}" for sid, d in sources.items()},
    }
    text = llm.chat([{"role": "system", "content": REPORTER}, {"role": "user", "content": str(facts)}], temperature=0)
    text = _risk_section(results.get("predict_failure")) + safety.enforce_advisory("", text)
    cited = set(re.findall(r"\[(S\d+)\]", text))
    if sources and not cited:  # the model forgot to cite: list the evidence it was given, so nothing is unsourced
        text += "\n\n### Sources\n" + "\n".join(f"- [{sid}] {d['doc_id']}" for sid, d in sources.items())
        cited = set(sources)
    citations = [{"source_id": sid, "doc_id": d["doc_id"], "snippet": d["text"][:300]}
                 for sid, d in sources.items() if sid in cited]
    return {"report": text, "citations": citations, "steps": state["steps"] + ["report"]}


def answer_direct_node(state: AgentState) -> AgentState:
    # Model routing: a general question goes to the cheaper model, with caching
    question = state["question"]
    if safety.asks_for_decision(question):
        text = safety.REFUSAL
    else:
        text = llm.chat([{"role": "system", "content": MAINTENANCE_ASSISTANT}, {"role": "user", "content": question}],
                        model=get_settings().chat_model_mini, temperature=0, use_cache=True)
        text = safety.enforce_advisory(question, text)
    return {"report": text, "citations": [], "steps": state["steps"] + ["answer_direct (mini model)"]}


def draft_work_order_node(state: AgentState) -> AgentState:
    results = state["results"]
    prediction = results.get("predict_failure") or {}
    compliance = results.get("check_compliance") or {}
    tasks, refs = [], [c["doc_id"] for c in state.get("citations", [])]
    if prediction.get("risk_level") == "high":
        tasks += [f"Review trend data for {state['engine_id']} (predicted RUL {prediction['predicted_rul_cycles']} cycles)",
                  "Do the engine vibration troubleshooting and borescope inspection (AMM 72-00-00)"]
    for ad in compliance.get("open", []):
        tasks.append(f"Accomplish {ad['ad_number']}: {ad['subject']}")
        refs.append(ad["ad_number"])
    work_order = {
        "work_order_id": "WO-" + uuid.uuid4().hex[:8].upper(),
        "tail_number": state["tail_number"],
        "engine_id": state.get("engine_id"),
        "title": f"AeroGuard recommended actions for {state['tail_number']}",
        "tasks": tasks,
        "references": sorted(set(refs)),
        "status": "draft",
    }
    security.audit("work_order_drafted", thread_id=state.get("thread_id"), work_order_id=work_order["work_order_id"],
                   role=state["role"])
    return {"work_order": work_order, "steps": state["steps"] + ["draft_work_order"]}


def approval_node(state: AgentState) -> AgentState:
    # Human-in-the-loop: the graph pauses here until an inspector answers
    decision = interrupt({"work_order": state["work_order"], "message": "Inspector approval required"})
    status = "approved" if decision.get("approve") else "rejected"
    work_order = dict(state["work_order"]) | {"status": status}
    security.audit("work_order_" + status, thread_id=state.get("thread_id"), work_order_id=work_order["work_order_id"],
                   approver=decision.get("approver"), role=decision.get("role"))
    return {"work_order": work_order, "decision": decision,
            "steps": state["steps"] + [f"approval: {status} by {decision.get('approver')}"]}


# ---------------------------------------------------------------- routing
def after_plan(state: AgentState) -> str:
    return "execute" if state["plan"] else "answer_direct"


def after_execute(state: AgentState) -> str:
    if state["plan"] and len(state["steps"]) <= MAX_STEPS:
        return "execute"
    return "report"


def after_report(state: AgentState) -> str:
    prediction = state["results"].get("predict_failure") or {}
    compliance = state["results"].get("check_compliance") or {}
    needs_action = prediction.get("risk_level") == "high" or bool(compliance.get("open"))
    if needs_action and security.safe_mode():
        security.audit("safe_mode_blocked_action", thread_id=state.get("thread_id"), action="draft_work_order")
        return END  # safe mode: report only, no actions
    return "draft_work_order" if needs_action and state.get("tail_number") else END


def _traced(name: str, fn):
    """Performance II: every graph step becomes a span in storage/traces.jsonl."""
    def wrapper(state: AgentState) -> AgentState:
        with tracing.span(f"agent.{name}", thread_id=state.get("thread_id") or ""):
            return fn(state)
    return wrapper


def build_graph(checkpointer=None):
    g = StateGraph(AgentState)
    for name, fn in [("plan", plan_node), ("execute", execute_node), ("report", report_node),
                     ("answer_direct", answer_direct_node), ("draft_work_order", draft_work_order_node)]:
        g.add_node(name, _traced(name, fn))
    g.add_node("approval", approval_node)  # not wrapped: interrupt() must pause the graph directly
    g.add_edge(START, "plan")
    g.add_conditional_edges("plan", after_plan, ["execute", "answer_direct"])
    g.add_conditional_edges("execute", after_execute, ["execute", "report"])
    g.add_conditional_edges("report", after_report, ["draft_work_order", END])
    g.add_edge("draft_work_order", "approval")
    g.add_edge("approval", END)
    g.add_edge("answer_direct", END)
    return g.compile(checkpointer=checkpointer)


@lru_cache
def get_graph():
    STORAGE_DIR.mkdir(exist_ok=True)
    conn = sqlite3.connect(STORAGE_DIR / "agent_checkpoints.sqlite", check_same_thread=False)
    return build_graph(SqliteSaver(conn))  # persistence: paused runs survive a server restart
