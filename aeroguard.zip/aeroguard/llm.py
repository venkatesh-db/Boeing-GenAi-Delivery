"""One LLM interface for the whole course (Day 2 onward).

Every call goes through `complete()`, which also records tokens, latency and
cost for the Day 5 observability lab.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass
from functools import lru_cache
from typing import Iterator, TypeVar

import contextlib

from openai import APIConnectionError, OpenAI
from pydantic import BaseModel, ValidationError

from aeroguard.config import get_settings
from aeroguard import tracing

T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True)
class Completion:
    text: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    latency_ms: float
    cached: bool = False


class LLMConnectionError(RuntimeError):
    """The LLM server could not be reached. The message says how to fix it."""


@contextlib.contextmanager
def friendly_errors() -> Iterator[None]:
    """Turn a long 'Connection refused' traceback into one line that says what to do."""
    try:
        yield
    except APIConnectionError:
        s = get_settings()
        if s.provider == "ollama":
            hint = (f"Ollama is not running at {s.base_url}. Start it in a terminal with `ollama serve` "
                    "(or once: `brew services start ollama`), then run this again.")
        else:
            hint = "Cannot reach the OpenAI API. Check your internet connection, proxy and OPENAI_API_KEY in .env."
        raise LLMConnectionError(hint) from None


@lru_cache
def client() -> OpenAI:
    s = get_settings()
    return OpenAI(api_key=s.api_key, base_url=s.base_url, timeout=180)


_cache: dict[str, Completion] = {}


def _cache_key(model: str, messages: list[dict], json_mode: bool) -> str:
    raw = json.dumps([model, messages, json_mode], sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()


def complete(
    messages: list[dict],
    model: str | None = None,
    temperature: float = 0.2,
    json_mode: bool = False,
    use_cache: bool = False,
    top_p: float | None = None,
) -> Completion:
    """Single chat completion. Caching applies only to deterministic calls."""
    model = model or get_settings().chat_model
    key = _cache_key(model, messages, json_mode)
    if use_cache and temperature == 0 and key in _cache:
        hit = _cache[key]
        result = Completion(hit.text, hit.model, 0, 0, 0.0, cached=True)
        tracing.record_llm_call(result)
        return result

    kwargs: dict = {"model": model, "messages": messages, "temperature": temperature}
    if top_p is not None:
        kwargs["top_p"] = top_p
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}
    start = time.perf_counter()
    with tracing.span("llm.complete", model=model), friendly_errors():
        resp = client().chat.completions.create(**kwargs)
    usage = resp.usage
    result = Completion(
        text=resp.choices[0].message.content or "",
        model=model,
        prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
        completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
        latency_ms=(time.perf_counter() - start) * 1000,
    )
    tracing.record_llm_call(result)
    if use_cache and temperature == 0:
        _cache[key] = result
    return result


def chat(messages: list[dict], **kwargs) -> str:
    return complete(messages, **kwargs).text


def chat_stream(messages: list[dict], model: str | None = None, temperature: float = 0.2) -> Iterator[str]:
    """Yield the answer piece by piece (Day 3 streaming)."""
    model = model or get_settings().chat_model
    with friendly_errors():
        stream = client().chat.completions.create(
            model=model, messages=messages, temperature=temperature, stream=True
        )
    for chunk in stream:
        if chunk.choices and chunk.choices[0].delta.content:
            yield chunk.choices[0].delta.content


def _extract_json(text: str) -> str:
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        raise ValueError("no JSON object found in the model output")
    return match.group(0)


def describe_fields(schema: type[BaseModel]) -> str:
    """Plain field list plus an example skeleton. Small models copy raw JSON Schema instead of filling it."""
    props = schema.model_json_schema()["properties"]
    lines, skeleton = [], {}
    for name, spec in props.items():
        kind = spec.get("type") or "/".join(o.get("type", "?") for o in spec.get("anyOf", [])) or "value"
        if "enum" in spec:
            kind = " | ".join(f'"{v}"' for v in spec["enum"])
        lines.append(f"- {name} ({kind}): {spec.get('description', '')}".rstrip(": "))
        skeleton[name] = {"string": "...", "integer": 0, "boolean": False, "array": ["..."], "number": 0.0}.get(
            spec.get("type", ""), "...")
    return "Fields:\n" + "\n".join(lines) + "\nShape (replace the placeholder values):\n" + json.dumps(skeleton)


def chat_json(messages: list[dict], schema: type[T], retries: int = 2, **kwargs) -> T:
    """Ask for JSON matching `schema`; on failure, send the error back and retry (Day 3)."""
    convo = list(messages)
    convo[0] = {
        "role": "system",
        "content": convo[0]["content"] + "\n\nReturn ONLY one JSON object with real values.\n" + describe_fields(schema),
    }
    last_error: Exception | None = None
    for _ in range(retries + 1):
        text = complete(convo, json_mode=True, temperature=0, **kwargs).text
        try:
            return schema.model_validate_json(_extract_json(text))
        except (ValidationError, ValueError) as err:
            last_error = err
            convo = convo + [
                {"role": "assistant", "content": text},
                {"role": "user", "content": f"That JSON was invalid: {err}. Return corrected JSON only."},
            ]
    raise ValueError(f"model did not return valid {schema.__name__} after {retries + 1} attempts: {last_error}")


def embed(texts: list[str]) -> list[list[float]]:
    """Embed a batch of texts (Day 4)."""
    s = get_settings()
    with tracing.span("llm.embed", model=s.embed_model, count=len(texts)), friendly_errors():
        resp = client().embeddings.create(model=s.embed_model, input=texts)
    return [d.embedding for d in resp.data]
